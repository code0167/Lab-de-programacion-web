'use strict';

// Reglas puras para limitar archivos y mensajes que puede solicitar la ventana.
const Core = require('../dist/core.js');
const APP_URL = 'aula://agenda/index.html';
const MAX_BACKUP_BYTES = Core.MAX_BACKUP_BYTES;
const ASSETS = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/styles.css': ['styles.css', 'text/css; charset=utf-8'],
  '/core.js': ['core.js', 'text/javascript; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/icon.svg': ['icon.svg', 'image/svg+xml']
};

const assetForUrl = (value) => {
  try {
    const url = new URL(value);
    if (url.protocol !== 'aula:' || url.host !== 'agenda' || url.username || url.password || url.search) return null;
    return Object.hasOwn(ASSETS, url.pathname) ? ASSETS[url.pathname] : null;
  } catch { return null; }
};

const isAppPage = (value) => {
  const asset = assetForUrl(value);
  return Boolean(asset && asset[0] === 'index.html');
};

const validateBackup = (text) => {
  if (typeof text !== 'string' || Buffer.byteLength(text, 'utf8') > MAX_BACKUP_BYTES) {
    throw new Error('La copia debe ser un archivo JSON de hasta 2 MB.');
  }
  return Core.encode(Core.decodeBackup(text));
};

module.exports = { APP_URL, MAX_BACKUP_BYTES, assetForUrl, isAppPage, validateBackup };
