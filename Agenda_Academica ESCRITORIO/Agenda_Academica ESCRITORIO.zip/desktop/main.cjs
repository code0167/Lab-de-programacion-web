'use strict';

const { app, BrowserWindow, Menu, dialog, ipcMain, protocol, session } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const { APP_URL, MAX_BACKUP_BYTES, assetForUrl, isAppPage, validateBackup } = require('./policy.cjs');

app.setName('Aula Agenda');
app.setAppUserModelId('com.aula.agenda');
app.enableSandbox();
app.commandLine.appendSwitch('lang', 'es');

// Esta carpeta no cambia al instalar una versión nueva.
const profilePath = path.join(app.getPath('appData'), 'AulaAgenda');
fs.mkdirSync(profilePath, { recursive: true });
app.setPath('userData', profilePath);
app.setPath('sessionData', profilePath);

protocol.registerSchemesAsPrivileged([
  { scheme: 'aula', privileges: { standard: true, secure: true, supportFetchAPI: true } }
]);

let mainWindow;
let dialogBusy = false;
const hasLock = app.requestSingleInstanceLock();
if (!hasLock) app.quit();

const assertSender = (event) => {
  if (!mainWindow || mainWindow.isDestroyed() || event.sender !== mainWindow.webContents
    || event.senderFrame !== mainWindow.webContents.mainFrame || !isAppPage(event.senderFrame.url)) {
    throw new Error('Solicitud no permitida.');
  }
};

const sendCommand = (command) => {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('aula:command', command);
};

const createMenu = () => {
  const template = [
    { label: 'Archivo', submenu: [
      { label: 'Nueva tarea', accelerator: 'CmdOrCtrl+N', click: () => sendCommand('new') },
      { type: 'separator' },
      { label: 'Exportar copia de tareas…', accelerator: 'CmdOrCtrl+Shift+E', click: () => sendCommand('export') },
      { label: 'Importar tareas…', accelerator: 'CmdOrCtrl+O', click: () => sendCommand('import') },
      { type: 'separator' },
      { label: 'Salir', accelerator: 'Alt+F4', click: () => app.quit() }
    ] },
    { label: 'Edición', submenu: [
      { label: 'Deshacer', role: 'undo' }, { label: 'Rehacer', role: 'redo' }, { type: 'separator' },
      { label: 'Cortar', role: 'cut' }, { label: 'Copiar', role: 'copy' },
      { label: 'Pegar', role: 'paste' }, { label: 'Seleccionar todo', role: 'selectAll' }
    ] },
    { label: 'Ver', submenu: [
      { label: 'Tamaño original', role: 'resetZoom' }, { label: 'Acercar', role: 'zoomIn' },
      { label: 'Alejar', role: 'zoomOut' }, { type: 'separator' },
      { label: 'Pantalla completa', role: 'togglefullscreen' }
    ] },
    { label: 'Ayuda', submenu: [{ label: 'Acerca de Aula', click: () => dialog.showMessageBox(mainWindow, {
      type: 'info', title: 'Acerca de Aula Agenda', message: `Aula Agenda ${app.getVersion()}`,
      detail: 'Tu semestre, en orden.\n\nFunciona sin internet y guarda tus tareas en esta computadora. Usa Exportar copia para conservar un respaldo o trasladarlas a otra instalación.',
      buttons: ['Entendido']
    }) }] }
  ];
  if (process.platform === 'darwin') template.unshift({ label: app.name, submenu: [{ role: 'about' }, { role: 'quit' }] });
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
};

const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 1250, height: 870, minWidth: 520, minHeight: 620,
    title: 'Aula Agenda', backgroundColor: '#f7f8f4', show: false,
    icon: path.join(__dirname, 'assets', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      devTools: !app.isPackaged
    }
  });
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (event, url) => { if (!isAppPage(url)) event.preventDefault(); });
  mainWindow.webContents.on('will-attach-webview', (event) => event.preventDefault());
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('close', () => session.defaultSession.flushStorageData());
  mainWindow.on('closed', () => { mainWindow = null; });
  mainWindow.loadURL(APP_URL).catch(() => {
    dialog.showErrorBox('No se pudo abrir Aula', 'Faltan archivos de la aplicación. Vuelve a instalarla sin borrar la carpeta de datos.');
    app.quit();
  });
};

const registerBackups = () => {
  ipcMain.handle('aula:save-backup', async (event, text) => {
    assertSender(event);
    if (dialogBusy) return { canceled: true };
    dialogBusy = true;
    try {
      const validated = validateBackup(text);
      const date = new Date().toISOString().slice(0, 10);
      const choice = await dialog.showSaveDialog(mainWindow, {
        title: 'Guardar copia de tus tareas', buttonLabel: 'Guardar copia',
        defaultPath: path.join(app.getPath('documents'), `Aula-tareas-${date}.json`),
        filters: [{ name: 'Copia de Aula (JSON)', extensions: ['json'] }]
      });
      if (choice.canceled || !choice.filePath) return { canceled: true };
      await fs.promises.writeFile(choice.filePath, validated, 'utf8');
      return { ok: true };
    } catch { return { error: 'No se pudo guardar la copia. Comprueba que elegiste una carpeta con permiso de escritura.' }; }
    finally { dialogBusy = false; }
  });

  ipcMain.handle('aula:open-backup', async (event) => {
    assertSender(event);
    if (dialogBusy) return { canceled: true };
    dialogBusy = true;
    try {
      const choice = await dialog.showOpenDialog(mainWindow, {
        title: 'Seleccionar copia de Aula', buttonLabel: 'Seleccionar',
        properties: ['openFile'], filters: [{ name: 'Copia de Aula (JSON)', extensions: ['json'] }]
      });
      if (choice.canceled || !choice.filePaths.length) return { canceled: true };
      const file = choice.filePaths[0];
      const stat = await fs.promises.stat(file);
      if (!stat.isFile() || stat.size > MAX_BACKUP_BYTES) return { error: 'Selecciona un archivo JSON de hasta 2 MB.' };
      return { text: validateBackup(await fs.promises.readFile(file, 'utf8')) };
    } catch { return { error: 'La copia no es válida o no se pudo leer. Tus tareas actuales se conservaron.' }; }
    finally { dialogBusy = false; }
  });
};

if (hasLock) {
  app.on('second-instance', () => {
    if (!mainWindow) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show(); mainWindow.focus();
  });

  app.whenReady().then(() => {
    protocol.handle('aula', async (request) => {
      const asset = assetForUrl(request.url);
      if (!asset || request.method !== 'GET') return new Response('No disponible', { status: 404 });
      try {
        return new Response(await fs.promises.readFile(path.join(__dirname, '..', 'dist', asset[0])), {
          headers: { 'Content-Type': asset[1], 'X-Content-Type-Options': 'nosniff',
            'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'self'" }
        });
      } catch { return new Response('Archivo no disponible', { status: 404 }); }
    });
    session.defaultSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
    session.defaultSession.setPermissionCheckHandler(() => false);
    registerBackups();
    createMenu();
    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  }).catch((error) => {
    console.error('No se pudo iniciar Aula:', error.message);
    dialog.showErrorBox('No se pudo iniciar Aula', 'Comprueba que la aplicación está instalada correctamente y vuelve a abrirla.');
    app.quit();
  });
}

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
