'use strict';

const { contextBridge, ipcRenderer } = require('electron');

// La interfaz recibe solamente estas funciones; nunca acceso a Node ni a rutas.
contextBridge.exposeInMainWorld('aulaDesktop', Object.freeze({
  saveBackup: (text) => ipcRenderer.invoke('aula:save-backup', text),
  openBackup: () => ipcRenderer.invoke('aula:open-backup'),
  onCommand: (callback) => {
    if (typeof callback !== 'function') return () => {};
    const listener = (_event, command) => {
      if (['new', 'export', 'import'].includes(command)) callback(command);
    };
    ipcRenderer.on('aula:command', listener);
    return () => ipcRenderer.removeListener('aula:command', listener);
  }
}));
