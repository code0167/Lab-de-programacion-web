; Instalador por usuario. No solicita permisos de administrador.
; Se compila con NSIS; no necesita ejecutar Windows durante la construcción.
Unicode true
RequestExecutionLevel user
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"
!include "WinVer.nsh"

Name "Aula Agenda"
OutFile "${OUTPUT_FILE}"
InstallDir "$LOCALAPPDATA\Programs\AulaAgenda"
SetCompressor /SOLID lzma
SetCompressorDictSize 16
BrandingText "Aula Agenda"
ShowInstDetails show
ShowUninstDetails show
VIProductVersion "${APP_VERSION}.0"
VIAddVersionKey /LANG=1034 "ProductName" "Aula Agenda"
VIAddVersionKey /LANG=1034 "FileDescription" "Instalador de Aula Agenda"
VIAddVersionKey /LANG=1034 "FileVersion" "${APP_VERSION}"
VIAddVersionKey /LANG=1034 "LegalCopyright" "Aula Agenda"

!define MUI_ICON "${APP_ICON}"
!define MUI_UNICON "${APP_ICON}"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Instalar Aula Agenda"
!define MUI_WELCOMEPAGE_TEXT "Tu semestre, en orden.$\r$\n$\r$\nSe instalará Aula Agenda para tu usuario y se crearán accesos en el escritorio y el menú Inicio.$\r$\n$\r$\nLa aplicación funciona sin internet. Tus tareas se guardan por separado y se conservan al desinstalar."
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN "$INSTDIR\Aula Agenda.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Abrir Aula Agenda"
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Spanish"

Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "Esta versión requiere Windows de 64 bits."
    Abort
  ${EndIf}
  ${IfNot} ${AtLeastWin10}
    MessageBox MB_OK|MB_ICONSTOP "Esta versión requiere Windows 10 u 11."
    Abort
  ${EndIf}
  SetShellVarContext current
  ; Fija el destino incluso si se pasa /D= en la línea de comandos.
  StrCpy $INSTDIR "$LOCALAPPDATA\Programs\AulaAgenda"
  check_open:
  FindWindow $0 "Chrome_WidgetWin_1" "Aula Agenda · Escritorio"
  ${If} $0 != 0
    MessageBox MB_RETRYCANCEL|MB_ICONEXCLAMATION "Cierra Aula Agenda antes de continuar." IDRETRY check_open
    Abort
  ${EndIf}
FunctionEnd

Function un.onInit
  SetShellVarContext current
  ${If} $INSTDIR != "$LOCALAPPDATA\Programs\AulaAgenda"
    MessageBox MB_OK|MB_ICONSTOP "Abre el desinstalador desde la ubicación original de Aula Agenda."
    Abort
  ${EndIf}
  check_open:
  FindWindow $0 "Chrome_WidgetWin_1" "Aula Agenda · Escritorio"
  ${If} $0 != 0
    MessageBox MB_RETRYCANCEL|MB_ICONEXCLAMATION "Cierra Aula Agenda antes de desinstalar." IDRETRY check_open
    Abort
  ${EndIf}
FunctionEnd

Section "Aula Agenda" SEC_APP
  SetShellVarContext current
  SetOutPath "$INSTDIR"
  ClearErrors
  File /r "${APP_DIRECTORY}/*"
  IfErrors 0 +3
    MessageBox MB_OK|MB_ICONSTOP "No se pudieron copiar todos los archivos. Cierra Aula y vuelve a ejecutar el instalador."
    Abort
  WriteUninstaller "$INSTDIR\Desinstalar-Aula.exe"
  CreateDirectory "$SMPROGRAMS\Aula Agenda"
  CreateShortCut "$DESKTOP\Aula Agenda.lnk" "$INSTDIR\Aula Agenda.exe"
  CreateShortCut "$SMPROGRAMS\Aula Agenda\Aula Agenda.lnk" "$INSTDIR\Aula Agenda.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda" "DisplayName" "Aula Agenda"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda" "DisplayVersion" "${APP_VERSION}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda" "DisplayIcon" "$INSTDIR\Aula Agenda.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda" "UninstallString" '"$INSTDIR\Desinstalar-Aula.exe"'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda" "EstimatedSize" ${SIZE_KB}
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda" "NoRepair" 1
SectionEnd

Section "Uninstall"
  SetShellVarContext current
  ; Lista exacta de archivos empaquetados, sin borrado recursivo de carpetas.
  !include "${REMOVE_FILES}"
  Delete "$INSTDIR\Desinstalar-Aula.exe"
  RMDir "$INSTDIR"
  Delete "$DESKTOP\Aula Agenda.lnk"
  Delete "$SMPROGRAMS\Aula Agenda\Aula Agenda.lnk"
  RMDir "$SMPROGRAMS\Aula Agenda"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\AulaAgenda"
  ; Nunca se borra $APPDATA\AulaAgenda: contiene las tareas personales.
SectionEnd
