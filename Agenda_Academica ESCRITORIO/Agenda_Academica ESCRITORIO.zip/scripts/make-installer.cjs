'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
// Adaptador de la versión fijada de electron-builder; descarga con su checksum.
const { getMakeNsisPath } = require('app-builder-lib/out/toolsets/windows');
const pkg = require('../package.json');
const root = path.join(__dirname, '..');
const appDirectory = path.join(root, 'release', 'win-unpacked');
const output = path.join(root, 'release', `Aula-Agenda-${pkg.version}-Instalador-Windows-x64.exe`);
const removeFile = path.join(root, 'release', 'remove-files.nsh');

const collect = (directory, relative = '') => {
  const files = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const filename = path.join(relative, entry.name);
    if (entry.isSymbolicLink()) throw new Error('No se permiten enlaces simbólicos en el instalador.');
    if (entry.isDirectory()) files.push(...collect(path.join(directory, entry.name), filename));
    else if (entry.isFile()) files.push(filename);
  }
  return files;
};
const escapeNsis = (value) => value.replace(/\$/g, '$$$$').replace(/"/g, '$\\"');

const makeInstaller = async () => {
  if (!fs.existsSync(path.join(appDirectory, 'Aula Agenda.exe'))) throw new Error('Primero ejecuta npm run pack:win.');
  const files = collect(appDirectory).sort();
  const directories = new Set();
  let size = 0;
  const lines = files.map((file) => {
    size += fs.statSync(path.join(appDirectory, file)).size;
    let dir = path.dirname(file);
    while (dir !== '.') { directories.add(dir); dir = path.dirname(dir); }
    return `Delete "$INSTDIR\\${escapeNsis(file.split(path.sep).join('\\'))}"`;
  });
  [...directories].sort((a, b) => b.length - a.length).forEach((dir) => {
    lines.push(`RMDir "$INSTDIR\\${escapeNsis(dir.split(path.sep).join('\\'))}"`);
  });
  fs.writeFileSync(removeFile, lines.join('\n') + '\n');
  const compiler = await getMakeNsisPath('0.0.0');
  const prefix = process.platform === 'win32' ? '/' : '-';
  const definitions = {
    APP_VERSION: pkg.version, APP_DIRECTORY: appDirectory, OUTPUT_FILE: output,
    APP_ICON: path.join(root, 'desktop', 'assets', 'icon.ico'),
    REMOVE_FILES: removeFile, SIZE_KB: String(Math.ceil(size / 1024))
  };
  const args = [`${prefix}V2`, ...Object.entries(definitions).map(([key, value]) => `${prefix}D${key}=${value}`), path.join(root, 'desktop', 'installer.nsi')];
  console.log(`Creando instalador: ${files.length} archivos. Las tareas del usuario quedan fuera del instalador.`);
  execFileSync(compiler.path, args, { cwd: root, stdio: 'inherit', env: { ...process.env, ...compiler.env } });
  console.log(`Instalador generado: ${output}`);
};
makeInstaller().catch((error) => { console.error(error.message); process.exitCode = 1; });
