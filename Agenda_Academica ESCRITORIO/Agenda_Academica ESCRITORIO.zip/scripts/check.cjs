'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const root = path.join(__dirname, '..');
for (const file of ['dist/app.js', 'dist/core.js', 'desktop/main.cjs', 'desktop/preload.cjs', 'desktop/policy.cjs']) {
  execFileSync(process.execPath, ['--check', path.join(root, file)], { stdio: 'inherit' });
}
for (const file of ['dist/index.html', 'dist/styles.css', 'dist/icon.svg', 'desktop/assets/icon.ico', 'desktop/assets/icon.png']) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Falta ${file}`);
}
console.log('Sintaxis y archivos necesarios: correctos.');
