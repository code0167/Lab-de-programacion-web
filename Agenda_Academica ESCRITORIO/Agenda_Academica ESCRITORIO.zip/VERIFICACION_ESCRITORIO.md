# Verificación de Aula Agenda para Windows

Entrega 1.0.0, Windows x64.

- `npm run check`: sintaxis y archivos necesarios correctos.
- `npm test`: 22 pruebas aprobadas, 0 fallos. Incluyen validación, filtros, copias, importación sin duplicados, cancelación, recuperación ante fallo de almacenamiento, aislamiento de la ventana y autorización de mensajes. Electron y los diálogos se simulan en estas pruebas.
- Prueba manual en Chrome: exportar JSON real, eliminar una tarea de ejemplo, importar la copia y confirmar la recuperación de esa tarea sin duplicar las otras tres.
- El instalador NSIS pasa la prueba de integridad completa de 7-Zip: 76 archivos, sin errores.
- El `app.asar` del instalador coincide byte a byte con el paquete construido. Los siete archivos de aplicación principales coinciden con el código fuente entregado.
- La web con controles de copia se publicó correctamente; conserva acceso privado.

## Comprobación pendiente en Windows

El entorno de construcción es Linux. No se ejecutaron aquí el instalador, la aplicación ni el desinstalador en Windows. No se afirma una prueba real de esos pasos.

En el equipo Windows: instalar, crear una tarea, cerrar y abrir para comprobar persistencia; exportar e importar una copia; revisar los accesos directos. Antes de probar la desinstalación, conservar una copia JSON. El desinstalador está diseñado para conservar `%APPDATA%\AulaAgenda`.

El ejecutable no tiene firma digital comercial. Las tareas de la web y del escritorio son independientes; no se sincronizan automáticamente. La importación conserva la versión existente si encuentra el mismo identificador.

## Repositorio incluido

El ZIP de código contiene los archivos fuente y `aula-agenda-desktop.bundle`, una copia Git con el historial. Para restaurarlo:

```bash
git clone aula-agenda-desktop.bundle aula-agenda
cd aula-agenda
git switch desktop
```

Los archivos `SHA256SUMS.txt` de la entrega permiten comparar las sumas de los archivos recibidos.
