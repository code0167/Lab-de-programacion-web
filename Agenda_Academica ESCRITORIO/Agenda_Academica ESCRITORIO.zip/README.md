# Aula Agenda · Aplicación de escritorio

Versión 1.0.0 para **Windows 10/11 de 64 bits (x64)**. Conserva la agenda académica original: tareas, materias, prioridades, notas, edición, eliminación, estados, filtros y progreso. Funciona sin internet ni inicio de sesión.

## Instalar y abrir

1. Extrae el ZIP de la entrega.
2. Ejecuta `Aula-Agenda-1.0.0-Instalador-Windows-x64.exe`.
3. Sigue el asistente en español. Se instala para tu usuario.
4. Abre **Aula Agenda** desde el escritorio o el menú Inicio.

El instalador incluye el motor necesario. Para utilizarlo no necesitas Node.js, Python, Visual Studio Code ni un servidor. La versión actual es x64; no es una aplicación para Android ni un paquete específico para Windows ARM.

El ejecutable de esta entrega no tiene firma digital comercial. Windows puede indicar que el editor es desconocido. La entrega incluye el código fuente y una suma SHA-256 para poder revisar su procedencia e integridad.

## Llevar tus tareas desde la web

1. Entra en tu agenda web con el mismo navegador donde están tus tareas.
2. Pulsa **Exportar copia** y guarda el archivo `.json`.
3. Abre Aula Agenda en Windows y pulsa **Importar copia**.
4. Selecciona ese JSON, revisa el resumen y confirma.

La importación **añade tareas con identificadores nuevos**. Si una tarea ya existe, conserva la versión que tienes abierta; no la sobrescribe ni duplica. No es sincronización automática: para llevar tareas nuevas entre equipos debes exportar e importar una copia.

Las copias tienen el mismo esquema `{"version":1,"tasks":[...]}` de la aplicación web. Se admiten archivos JSON de hasta 2 MB. Los archivos inválidos se rechazan sin cambiar la agenda. Puedes exportar tareas de la sesión incluso si el almacenamiento local muestra un error.

## Dónde se guardan los datos

- Los datos de la aplicación permanecen en el perfil de tu usuario: `%APPDATA%\AulaAgenda`.
- Los archivos del programa se instalan en `%LOCALAPPDATA%\Programs\AulaAgenda`.
- La aplicación web y la de escritorio tienen almacenes separados.
- El desinstalador conserva la carpeta de datos; reinstalar permite volver a utilizarla.
- **Exportar copia** guarda un respaldo JSON en la carpeta que tú elijas.

No modifiques manualmente los archivos internos de Chromium. Para conservar y trasladar tareas utiliza la copia JSON.

## Atajos y menús

| Acción | Atajo |
| --- | --- |
| Nueva tarea | Ctrl + N |
| Exportar copia | Ctrl + Mayús + E |
| Importar copia | Ctrl + O |
| Cerrar | Alt + F4 |

Los menús **Archivo**, **Edición**, **Ver** y **Ayuda** incluyen las acciones habituales. Abrir el programa dos veces enfoca la ventana existente para evitar dos sesiones de edición independientes.

## Ejecutar desde el código fuente

Solo necesitas estos pasos si quieres modificar el proyecto; el instalador ya está construido.

1. Instala Node.js 24 LTS en tu equipo.
2. Extrae `Aula_Agenda_Codigo_Fuente.zip` y abre una terminal en esa carpeta.
3. Ejecuta:

```bash
npm ci
npm start
```

Para comprobar el código:

```bash
npm run check
npm test
```

Para volver a generar la versión de Windows:

```bash
npm run dist:win
```

El resultado queda en `release/Aula-Agenda-1.0.0-Instalador-Windows-x64.exe`. La primera compilación descarga Electron y las herramientas de empaquetado. `package-lock.json` fija las dependencias. `npm run pack:win` genera solamente la carpeta ejecutable, sin instalador.

## Organización

| Ubicación | Contenido |
| --- | --- |
| `dist/` | HTML, CSS y JavaScript de la agenda, compartidos con la versión web. |
| `desktop/main.cjs` | Ventana, perfil local, menú, protocolo de recursos y diálogos nativos. |
| `desktop/preload.cjs` | Puente limitado para importar y exportar, sin exponer Node al formulario. |
| `desktop/policy.cjs` | Validación de URLs y copias. |
| `desktop/assets/` | Iconos derivados del SVG original. |
| `desktop/installer.nsi` | Instalador y desinstalador por usuario. |
| `scripts/make-installer.cjs` | Generación del instalador con NSIS nativo, también desde Linux. |
| `tests/` | Pruebas de datos, copias, interfaz simulada y arranque simulado. |
| `README_WEB.md` | Documentación de la actividad académica original. |

El instalador usa una ubicación fija por usuario y genera una lista exacta de archivos que puede eliminar. No borra carpetas recursivamente ni elimina las tareas personales. El script de compilación utiliza el compilador NSIS provisto y verificado por la versión fijada de electron-builder; evita necesitar Wine en el entorno de construcción.

La ventana mantiene el aislamiento de contexto y el sandbox activados, no permite Node en la interfaz ni navegación a páginas externas, y solo expone dos operaciones de copia validadas. La aplicación no incluye telemetría ni un sistema de actualización automática.

## Verificación y límites

El código se comprobó con pruebas automatizadas; la exportación e importación también se revisaron en Chrome con un archivo real. El instalador y el ejecutable de Windows se generaron desde Linux. **No se pudo ejecutar una instalación real en Windows en este entorno**; ese paso queda pendiente de comprobar en tu PC.

La entrega no incluye certificado de firma ni actualizador automático. Conserva una copia JSON antes de cambiar de versión.

## Referencias técnicas

- [Seguridad de Electron](https://www.electronjs.org/docs/latest/tutorial/security).
- [Protocolo de recursos de Electron](https://www.electronjs.org/docs/latest/api/protocol).
- [Diálogos nativos](https://www.electronjs.org/docs/latest/api/dialog).
- [Referencia de NSIS](https://nsis.sourceforge.io/Docs/Chapter4.html).

El código conserva la licencia de proyecto privado `UNLICENSED`. Los componentes redistribuidos incluyen sus avisos de licencia de Electron y Chromium.
