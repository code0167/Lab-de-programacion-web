'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { EventEmitter } = require('node:events');
const { createRequire } = require('node:module');
const entry = path.join(__dirname, '..', 'desktop', 'main.cjs');
const localRequire = createRequire(entry);

const bootstrap = async (t) => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'aula-main-test-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const state = { handlers: {}, directory, savedFile: path.join(directory, 'backup.json'), openResult: { canceled: true }, window: null };
  const app = Object.assign(new EventEmitter(), {
    setName: () => {}, setAppUserModelId: () => {}, enableSandbox: () => { state.sandbox = true; },
    commandLine: { appendSwitch: () => {} }, getPath: () => directory, setPath: () => {},
    requestSingleInstanceLock: () => true, quit: () => {}, whenReady: () => Promise.resolve(),
    getVersion: () => '1.0.0', isPackaged: true
  });
  class Window extends EventEmitter {
    constructor(options) {
      super(); state.window = this; state.options = options;
      this.webContents = Object.assign(new EventEmitter(), {
        mainFrame: { url: 'aula://agenda/index.html' },
        setWindowOpenHandler: (handler) => { state.newWindow = handler; }, send: () => {}
      });
    }
    loadURL(url) { state.url = url; return Promise.resolve(); }
    isDestroyed() { return false; }
    show() {}
    static getAllWindows() { return [state.window]; }
  }
  const electron = {
    app, BrowserWindow: Window,
    Menu: { buildFromTemplate: (value) => value, setApplicationMenu: (value) => { state.menu = value; } },
    dialog: { showMessageBox: async () => ({}), showErrorBox: (_title, detail) => { throw new Error(detail); },
      showSaveDialog: async () => ({ canceled: false, filePath: state.savedFile }), showOpenDialog: async () => state.openResult },
    ipcMain: { handle: (name, handler) => { state.handlers[name] = handler; } },
    protocol: { registerSchemesAsPrivileged: (value) => { state.schemes = value; }, handle: (_name, handler) => { state.protocol = handler; } },
    session: { defaultSession: { setPermissionRequestHandler: () => {}, setPermissionCheckHandler: () => {}, flushStorageData: () => {} } }
  };
  vm.runInNewContext(fs.readFileSync(entry, 'utf8'), {
    require: (name) => name === 'electron' ? electron : localRequire(name),
    __dirname: path.dirname(entry), process, console, Response
  });
  await new Promise((resolve) => setImmediate(resolve));
  state.event = { sender: state.window.webContents, senderFrame: state.window.webContents.mainFrame };
  return state;
};

test('el arranque limita la ventana y sirve únicamente los recursos de Aula', async (t) => {
  const app = await bootstrap(t);
  assert.equal(app.sandbox, true);
  assert.equal(app.options.webPreferences.nodeIntegration, false);
  assert.equal(app.options.webPreferences.contextIsolation, true);
  assert.equal(app.options.webPreferences.sandbox, true);
  assert.equal(app.newWindow().action, 'deny');
  assert.equal(app.url, 'aula://agenda/index.html');
  const page = await app.protocol({ url: app.url, method: 'GET' });
  assert.equal(page.status, 200);
  assert.match(await page.text(), /Tu semestre/);
  assert.match(page.headers.get('Content-Security-Policy'), /connect-src 'none'/);
  assert.equal((await app.protocol({ url: 'aula://agenda/package.json', method: 'GET' })).status, 404);
});

test('los mensajes de copia validan el origen y usan solamente el archivo elegido', async (t) => {
  const app = await bootstrap(t);
  await assert.rejects(app.handlers['aula:save-backup']({ ...app.event, senderFrame: { url: 'https://otro.example' } }, '{"version":1,"tasks":[]}'));
  const saved = await app.handlers['aula:save-backup'](app.event, '{"version":1,"tasks":[]}');
  assert.equal(saved.ok, true);
  assert.deepEqual(JSON.parse(fs.readFileSync(app.savedFile, 'utf8')), { version: 1, tasks: [] });
  app.openResult = { canceled: false, filePaths: [app.savedFile] };
  assert.equal((await app.handlers['aula:open-backup'](app.event)).text, '{"version":1,"tasks":[]}');
  fs.writeFileSync(app.savedFile, 'corrupto');
  assert.match((await app.handlers['aula:open-backup'](app.event)).error, /no es válida/);
});
