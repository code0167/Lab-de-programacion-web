'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const Core = require('../dist/core.js');
const Policy = require('../desktop/policy.cjs');
const task = { id: 'tarea-1', title: 'Tarea original', subject: 'Programación Web', dueDate: '2026-11-10', priority: 'alta', notes: 'Notas', completed: false, createdAt: '2026-10-28T12:00:00.000Z', updatedAt: '2026-10-28T12:00:00.000Z' };

test('la copia JSON admite BOM y conserva el esquema de la agenda web', () => {
  assert.deepEqual(Core.decodeBackup('\uFEFF' + Core.encode([task])), [task]);
  assert.deepEqual(JSON.parse(Policy.validateBackup(Core.encode([task]))), { version: 1, tasks: [task] });
});

test('importar añade nuevas tareas y conserva conflictos por ID sin duplicarlos', () => {
  const current = [task];
  const incoming = [{ ...task, title: 'Cambios externos' }, { ...task, id: 'tarea-2' }];
  const merged = Core.mergeTasks(current, incoming);
  assert.equal(merged.added, 1);
  assert.equal(merged.skipped, 1);
  assert.equal(merged.tasks[0].title, 'Tarea original');
  assert.equal(current.length, 1);
  assert.equal(Core.mergeTasks(merged.tasks, incoming).added, 0);
});

test('las copias grandes, corruptas y con identificadores duplicados se rechazan', () => {
  for (const raw of [null, '{}', 'null', 'archivo inválido', 'a'.repeat(Core.MAX_BACKUP_BYTES + 1), Core.encode([task, task])]) {
    assert.throws(() => Core.decodeBackup(raw));
    assert.throws(() => Policy.validateBackup(raw));
  }
});

test('el protocolo solo sirve los archivos permitidos y no rutas del equipo', () => {
  assert.deepEqual(Policy.assetForUrl('aula://agenda/index.html'), ['index.html', 'text/html; charset=utf-8']);
  assert.equal(Policy.isAppPage('aula://agenda/#main'), true);
  for (const url of ['file:///etc/passwd', 'https://example.com/', 'aula://otro/index.html', 'aula://agenda/desktop/main.cjs', 'aula://agenda/%2e%2e%2fpackage.json', 'aula://user@agenda/index.html', 'aula://agenda/index.html?x=1', 'bad']) {
    assert.equal(Policy.assetForUrl(url), null, url);
    assert.equal(Policy.isAppPage(url), false, url);
  }
  assert.equal(Policy.isAppPage('aula://agenda/app.js'), false);
});
