'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
const Core = require('../dist/core.js');

const root = path.join(__dirname, '..');
const task = { id: 'tarea-1', title: 'Tarea original', subject: 'Programación Web', dueDate: '2026-11-10', priority: 'alta', notes: 'Notas', completed: false, createdAt: '2026-10-28T12:00:00.000Z', updatedAt: '2026-10-28T12:00:00.000Z' };
const tick = () => new Promise((resolve) => setImmediate(resolve));

const setup = (initial = [], backup = null) => {
  const dom = new JSDOM(fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8'), { url: 'https://aula.test/', runScripts: 'outside-only' });
  const window = dom.window;
  window.TextEncoder = TextEncoder;
  window.HTMLElement.prototype.scrollIntoView = () => {};
  window.HTMLDialogElement.prototype.showModal = function () { this.open = true; };
  window.HTMLDialogElement.prototype.close = function (value) { this.returnValue = value; this.open = false; this.dispatchEvent(new window.Event('close')); };
  window.localStorage.setItem('aula.agenda.v1', Core.encode(initial));
  const calls = { saved: null, command: null };
  window.aulaDesktop = {
    saveBackup: async (text) => { calls.saved = text; return { ok: true }; },
    openBackup: async () => backup === null ? { canceled: true } : { text: backup },
    onCommand: (callback) => { calls.command = callback; }
  };
  window.eval(fs.readFileSync(path.join(root, 'dist/core.js'), 'utf8'));
  window.eval(fs.readFileSync(path.join(root, 'dist/app.js'), 'utf8'));
  return { dom, window, document: window.document, calls, read: () => Core.decode(window.localStorage.getItem('aula.agenda.v1')) };
};

test('el modo escritorio muestra almacenamiento local y exporta todos los datos', async (t) => {
  const app = setup([task]);
  t.after(() => app.window.close());
  assert.equal(app.document.title, 'Aula Agenda · Escritorio');
  assert.match(app.document.querySelector('#storage-status').textContent, /esta computadora/);
  app.document.querySelector('#export-backup').click();
  await tick();
  assert.deepEqual(Core.decode(app.calls.saved), [task]);
});

test('la importación pide confirmar y conserva el registro existente', async (t) => {
  const app = setup([task], Core.encode([{ ...task, title: 'Versión externa' }, { ...task, id: 'tarea-2', title: 'Tarea importada' }]));
  t.after(() => app.window.close());
  app.document.querySelector('#import-backup').click();
  await tick();
  assert.equal(app.document.querySelector('#confirm-dialog').open, true);
  assert.equal(app.read().length, 1);
  app.document.querySelector('#confirm-action').click();
  assert.equal(app.read().length, 2);
  assert.equal(app.read()[0].title, 'Tarea original');
  assert.equal(app.document.querySelectorAll('.task-card').length, 2);
  app.document.querySelector('#import-backup').click();
  await tick();
  assert.equal(app.document.querySelector('#confirm-dialog').open, false);
  assert.equal(app.read().length, 2);
});

test('cancelar la confirmación no cambia ninguna tarea', async (t) => {
  const app = setup([task], Core.encode([{ ...task, id: 'tarea-2' }]));
  t.after(() => app.window.close());
  app.document.querySelector('#import-backup').click();
  await tick();
  app.document.querySelector('#confirm-dialog button[value="cancel"]').click();
  assert.deepEqual(app.read(), [task]);
});

test('una copia corrupta no cambia ni borra los registros existentes', async (t) => {
  const app = setup([task], '{incorrecto}');
  t.after(() => app.window.close());
  app.calls.command('import');
  await tick();
  assert.deepEqual(app.read(), [task]);
  assert.equal(app.document.querySelector('#confirm-dialog').open, false);
  assert.match(app.document.querySelector('#toast').textContent, /no es válida/);
});

test('cancelar el selector y usar el menú exportar no modifica la agenda', async (t) => {
  const app = setup([task]);
  t.after(() => app.window.close());
  app.calls.command('import');
  await tick();
  assert.equal(app.document.querySelector('#confirm-dialog').open, false);
  app.calls.command('export');
  await tick();
  assert.deepEqual(Core.decode(app.calls.saved), [task]);
  assert.deepEqual(app.read(), [task]);
});

test('exportar rescata las tareas de la sesión cuando localStorage falla', async (t) => {
  const app = setup();
  t.after(() => app.window.close());
  app.window.Storage.prototype.setItem = () => { throw new Error('QuotaExceededError'); };
  app.document.querySelector('#load-examples').click();
  assert.equal(app.document.querySelector('#storage-warning').hidden, false);
  assert.deepEqual(app.read(), []);
  app.document.querySelector('#export-backup').click();
  await tick();
  assert.equal(Core.decode(app.calls.saved).length, 4);
});
